/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eshoppies;

/**
 *
 * @author felix
 */
public class loginSession {
    public static int UID; //global user id
    public static String usertype; //global usertype
    public static String nickname;
    public static boolean issLoggedIn = false; //
    
    
}
