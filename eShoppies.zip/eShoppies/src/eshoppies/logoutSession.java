/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eshoppies;

import javax.swing.JFrame;

/**
 *
 * @author felix
 */
public class logoutSession {
    public static void logout(JFrame context, login logInScreen){
        loginSession.issLoggedIn = false;
        context.setVisible(false);
        logInScreen.setVisible(true);
    }
    
}
